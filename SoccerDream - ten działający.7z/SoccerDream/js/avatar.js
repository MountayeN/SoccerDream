var i = 1;

function arrow_left_avatar1() {
    if (i < 4) {
        i = i + 1;
        document.getElementById("avatar").style.backgroundImage = "url('./image/avatars/bialy" + i + ".png')";
    }
}
function arrow_right_avatar1() {
    if (i >= 2) {
        i = i - 1;
        document.getElementById("avatar").style.backgroundImage = "url('./image/avatars/bialy" + i + ".png')";
    }
}
function arrow_left_avatar2() {
    if (i < 4) {
        i = i + 1;
        document.getElementById("avatar").style.backgroundImage = "url('./image/avatars/chinol" + i + ".png')";
    }
}
function arrow_right_avatar2() {
    if (i >= 2) {
        i = i - 1;
        document.getElementById("avatar").style.backgroundImage = "url('./image/avatars/chinol" + i + ".png')";
    }
}
function arrow_left_avatar3() {
    if (i < 4) {
        i = i + 1;
        document.getElementById("avatar").style.backgroundImage = "url('./image/avatars/czarnuch" + i + ".png')";
    }
}
function arrow_right_avatar3() {
    if (i >= 2) {
        i = i - 1;
        document.getElementById("avatar").style.backgroundImage = "url('./image/avatars/czarnuch" + i + ".png')";
    }
}