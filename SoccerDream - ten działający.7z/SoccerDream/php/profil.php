<?php
    session_start();
    $login=$_GET['login'];
    $laczenie=mysqli_connect('localhost', 'root', '', 'soccerdream');

    $sql=mysqli_query($laczenie, "SELECT * FROM users WHERE email='$login'");

    while ($r = mysqli_fetch_assoc($sql)) {
        echo "
            <div class='row'>".$r['nick']."</div>
        ";
    }
?>