<?php
session_start();

$laczenie=mysqli_connect('localhost', 'root', '', 'soccerdream');
mysqli_query($laczenie, "SET NAMES utf8");


$email="user@gmail.com";
$password="password";
if($_POST['email']==$email && $_POST['password']==$password){
    $_SESSION['zalogowany']=1;
    header('Location: ../index.php');
}
else{
    $_SESSION['zalogowany']=2;
    header('Location: ../index.php');
}