<?php
session_start();
$login=$_POST['email'];
$password=$_POST['password'];
$laczenie=mysqli_connect('localhost', 'root', '', 'soccerdream');
mysqli_query($laczenie, "SET NAMES utf8");

$check=mysqli_query($laczenie,"SELECT * FROM users WHERE email='$login' AND password='$password'");

if($check->num_rows == 0){
    $_SESSION['zalogowany']=2;
    header('Location: ../index.php');
   
}
else{
    $_SESSION['zalogowany']=1;
    header('Location: ../index.php');
   
}