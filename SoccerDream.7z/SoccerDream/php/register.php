<?php
    if ((isset($_POST['nick'])) && (isset($_POST['email'])) && (isset($_POST['password']))) {
        $nick = $_POST['nick'];
        $email = $_POST['email'];
        $password = $_POST['password'];
    
        $laczenie=mysqli_connect('localhost', 'root', '', 'soccerdream');
        mysqli_query($laczenie, "SET NAMES utf8");
    
        mysqli_query($laczenie, "INSERT INTO users (`id`, `nick`, `email`, `password`) VALUES ('', '$nick', '$email', '$password');");
        header("Location: ../index.php");
    }
?>